/**
 * 
 */
/**
 * 
 */
module CoreJavaAssignment {
}