package CoreJavaPkj;

public class ValueOfC {
	
	
	public static float returnNumber(){  
		float c = 0;
		float a = 7.8f;
		float b = 4.4f;
		 c=a+b;
		 return c;
		 }

	

	public static void main(String[] args) {
		
		float result= returnNumber();
		System.out.println("Value of C is: "+result);

	}

}
