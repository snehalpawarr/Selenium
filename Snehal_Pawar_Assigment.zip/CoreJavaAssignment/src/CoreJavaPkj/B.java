package CoreJavaPkj;

public class B {
	
	    int number;

	    
	    public void ClassB() {
	        this.number = 0; 
	    }

	   
	    public void setNumber(int number) {
	        this.number = number;
	    }

}
