package CoreJavaPkj;

public class Loop {

	public static void main(String[] args) {
	 for(int i=500; i<=1000;i++) {
		 if(i==808)
			 System.out.println("Number found as 808");
	 }

	}

}
